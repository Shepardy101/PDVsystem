-- Migration: Adiciona coluna imageUrl à tabela products
ALTER TABLE products ADD COLUMN imageUrl TEXT;
