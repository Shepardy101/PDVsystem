-- Adiciona configuração Enable_Negative_Casher padrão (false)
INSERT OR IGNORE INTO settings (key, value) VALUES ('Enable_Negative_Casher', 'false');
