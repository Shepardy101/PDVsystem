ALTER TABLE cash_movements ADD COLUMN category TEXT DEFAULT '';
