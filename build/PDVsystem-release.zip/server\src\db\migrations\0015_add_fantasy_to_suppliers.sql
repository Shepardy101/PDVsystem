-- Migration: Adiciona coluna fantasy à tabela suppliers
ALTER TABLE suppliers ADD COLUMN fantasy TEXT;
