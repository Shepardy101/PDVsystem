ALTER TABLE cash_movements ADD COLUMN operator_id TEXT;
