export const PORT = process.env.PORT || 8787;
export const DB_PATH = process.env.DB_PATH || 'data/novabev.sqlite';
